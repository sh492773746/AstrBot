# AI 账号服务总控

`astrbot_plugin_telethon_ai` 将 Telegram 服务入口、租户授权和 Telethon AI 账号接入同一个 AstrBot。VIP 总控负责平台运维；客户拥有的服务 Bot 只负责本租户的服务菜单；获授权的 Telethon 账号才会使用 AstrBot 的模型处理群内触发的对话。本插件不提供客户 Web 管理端或独立 HTTP 服务。

> **安装兼容性：**当前运行环境是经过本地扩展的 AstrBot v4.28.1。已在隔离环境验证：未修改的官方 v4.28.1 可以导入插件，但缺少总控绑定所需的 Telegram adapter 接口，不能直接完成此版本的总控工作流。`metadata.yaml` 的版本范围不是“全新原版安装即用”的认证。不要把生产配置或核心补丁当成插件安装包的一部分。

## 架构

```mermaid
flowchart TB
    operator["平台超管"] --> vip["VIP_DHBot 总控 Bot"]
    owner["租户所有者"] --> clone["客户服务 Bot（Managed Bot）"]
    members["授权群成员"] --> group["已授权 Telegram 群"]

    subgraph astr["同一个 AstrBot 进程"]
        vip --> vipProfile["VIP_DHBot:: 总控配置档"]
        vipProfile --> ctrl["插件：总控命令 / 开通审核"]
        clone --> cloneProfile["AIClient_*:: 客户配置档（无 LLM）"]
        cloneProfile --> menu["插件：租户服务菜单 / 所有权校验"]
        ctrl --> ledger["租户数据库：额度 / 授权 / 租期 / 审计"]
        menu --> ledger
        ledger --> gate["账号租约 + 请求额度网关"]

        subgraph ai["Telethon 账号 AI 链路"]
            inbound["Telethon 账号：群消息入口"] --> gate
            gate --> account["账号专属 AstrBot 配置档 / 人格"]
            account --> pipeline["AstrBot 对话流水线"]
            pipeline <--> provider["共享模型供应商注册表"]
            pipeline --> outbound["发送前权限复核 + AI 标识"]
        end
    end

    group --> inbound
    outbound --> group
```

箭头表示**管理或消息流**，不是共享管理员权限。总控 Bot 不替 Telethon 账号发言，客户服务 Bot 也不直接生成群聊回复。普通克隆是在**同一个 AstrBot** 中增加一个受限的 Telegram 平台和配置档，不是按客户复制完整 AstrBot/数据库；租户在业务数据库内按所有者、Bot、账号租约和群授权做逻辑隔离。它不是抵御不可信 Python 插件的进程级隔离，高隔离定制需要另外部署。

### 模型、人格与知识库

| 范围 | 当前行为 |
| --- | --- |
| `VIP_DHBot::` 总控配置档 | 决定总控 Bot 的 AstrBot 行为；当前生产配置关闭自动 LLM，由总控插件处理服务命令。 |
| `AIClient_*::` 客户配置档 | 仅为客户服务 Bot 提供管理菜单；不启用自动 LLM，不承载 Telethon 群聊。 |
| `TelethonAI_<账号>::` 账号配置档 | 每个账号独立路由、人格、会话和允许的插件；启用 LLM 后由 AstrBot 原生流水线调用模型。 |
| 模型供应商与密钥 | 同属一个 AstrBot 的供应商注册表。创建账号配置档时，可用插件指定的模型 ID；留空时**读取当时**总控配置档的模型 ID 作为初始值。后续修改 VIP 模型不会自动同步已有账号配置档。 |
| 人格与知识库 | 账号首次建档可用 `SOUL.md` 建立其独立人格；之后各账号分别维护。总控人格不会自动复制。当前账号配置档的 `kb_names` 为空，账号链路不接入总控知识库；并限制工具调用。 |

因此，“复用 VIP 配置文件的对话模型”只指初次建档时选用的**模型 ID**及同一供应商资源，不是复用总控的整份配置、提示词、聊天记录或知识库。生产实例实际使用什么模型应以各账号配置档当前值为准。

## 功能边界

- **总控：**管理员审核试用、登记客户 Bot、分配账号、授权群、启停服务、审核恢复与群授权申请、查看续期申请和紧急停止。续期申请当前不能通过自动审核命令直接续期。Managed Bot 创建需由用户通过 Telegram 确认，不能自行凭空生成客户 Bot。
- **客户服务 Bot：**仅绑定的所有者可查看服务与额度、暂停服务、申请恢复/续期和提交群授权申请；不提供模型密钥、人格、其他客户数据或平台运维入口。Bot 身份、发消息的用户 ID 和所在私聊均在后端重新校验。Bot 平台使用 `telegram_dedicated_reporting=true` 禁止进入 AstrBot 原生消息/LLM 流水线，所有 Telegram 更新由插件独占处理；插件异常时不向其他插件转发。
- **Telethon AI：**仅处理明确授权的群和发送者在允许条件下的提及/回复；不主动聊天、自动入群或邀请账号，不将账号间消息循环传递。输出带 `[AI]` 标识，不能把它当作未披露的真人聊天服务。
- **额度：**租户请求总额度和账号 UTC 每日上限/冷却时间分别控制；每日计数是网关接纳次数，并非模型 token 消耗或所有成功发言数。发送前还会复核租期、租约、群授权与暂停状态。不确定是否已发送时暂停并人工复核，不自动重试发言。
- **商业化：**当前只开放管理员审核的试用。Stars 购买、自动收款、续费与退款尚未启用；不要把 `/plans` 或“申请续期”当作已开通付费能力。

租户“已启用”、账号“已连接”、群“已授权”和账号“未紧急暂停”是不同条件；其中任何条件不满足都不代表可以发言。后台解除紧急暂停不会自动连接已经停止的 Telethon 平台。

## Telegram 入口

总控 Bot 的公开私聊命令：`/start`、`/help`、`/bots`、`/create`、`/plans`。`/create` 需要有效试用资格及总控 Bot 的 Bot Management Mode。

总控超管命令**只接受插件 `admin_ids` 配置的数字 ID 的私聊**：

| 命令 | 用途 |
| --- | --- |
| `/tgai help` | 查看平台管理帮助。 |
| `/tgaigrant OWNER_ID DAYS` | 签发 1–7 天的试用资格。 |
| `/tgaitrial OWNER_ID BOT_ID AIClient_NAME` | 人工登记已有服务 Bot。 |
| `/tgaiassign TENANT ACCOUNT` | 分配账号租约。 |
| `/tgaigroup TENANT -100GROUP` | 审核通过后授权群。 |
| `/tgaienable TENANT`、`/tgaidisable TENANT` | 启用或暂停租户服务。 |
| `/tgairetry BOT_ID` | 复核后重试未完成的开通。 |
| `/tgairequests`、`/tgaiapprove REQUEST_ID`、`/tgaireject REQUEST_ID` | 处理客户申请。 |
| `/tgaistop` | 紧急停止账号 AI 发言。 |

变更型管理命令除紧急停止外采用绑定发起人、聊天和参数的五分钟单次确认；确认状态在进程内，重载后需要重新发起。平台操作记入业务审计。

客户服务 Bot 在私聊支持 `/start`、`/service`、`/pause`、`/resume`、`/renew`、`/bind -100群ID`，以及“我的服务”“查看额度”“暂停服务”“申请恢复”“申请续期”等键盘操作。群授权申请**不等于**获得授权，平台必须核验群管理权和授权范围；服务 Bot 不会自动邀请 Telethon 账号入群。

## 安装和配置

1. 准备可用的 AstrBot、Telegram 总控平台（如 `VIP_DHBot`）与模型供应商。**先检查下文的兼容性要求**，不能把未修改的 v4.28.1 直接视作可用运行底座。
2. 将本插件安装到 AstrBot 并仅加载一次；总控、客户 Bot 和账号配置档分别将其列入各自的 `plugin_set`。设置 `control_platform_id`、超管的数字 `admin_ids`、`support_text`；`controller_mode=standalone` 为独立总控模式，`companion` 只用于旧总控迁移。`provision_profiles` 控制首次为私有账号注册表建档，`model_provider_id` 可固定新账号初始模型。新建客户 Bot 固定使用 `telegram_required_plugin=astrbot_plugin_telethon_ai`、`telegram_dedicated_reporting=true`、`telegram_command_register=false`，仅订阅消息更新。配置档必须禁用 LLM、内置命令、管理后台和知识库，且仅允许此插件；运行时每次操作都复核配置路由。
3. 在**服务器终端**使用 `setup_account.py` 建立专用 Telethon 账号会话，保管 API 凭据和 Session；插件不会要求客户 Bot 接收登录验证码。初次建档检查 `TelethonAI_<账号>::` 路由、模型和人格；账号平台默认关闭，需要在授权群和租约确认后按需开启。
4. 平台超管发放试用资格，客户在总控私聊 `/create` 并确认新 Bot；待注册、账号分配、群授权和账号连接分别核验后再做小范围测试。
5. 运行状态可在 AstrBot 内部原生插件页面的“账号 / 租户 / 诊断 / 试聊”查看。该页面供平台内部维护；客户所有服务入口均在 Telegram，不需要租户域名或对外 WebUI。“正在连接”表示页面正在连接 AstrBot 页面桥或状态接口，**不是** Telethon 账号正在登录。加载失败可重试；单凭 URL 的未授权标记不能判定故障原因。

## 数据、安全与迁移

插件数据位于 AstrBot 的 `data/plugin_data/astrbot_plugin_telethon_ai/`：租户业务及额度记录为 SQLite，`private/` 保存账号注册信息、会话引用和 Managed Bot 密钥。Managed Bot Token 在业务库中加密，但 AstrBot 原生 Telegram 平台配置也会保存可用 Token，因此**整个 AstrBot 数据目录都要按敏感资产保护**。不要将数据库、密钥、平台配置或 Session 打进插件 ZIP。

备份/恢复应同时覆盖业务库、额度库、Fernet 密钥、账号注册表、Session 与 AstrBot 平台/配置档，并校验对应关系；单独恢复数据库可能使 Bot Token 不可解密或路由失配。插件重载会断开账号连接，维护后须检查账号平台是否重新运行。旧总控、旧试验实例及遗留 worker 不应与本插件同时轮询同一个总控 Bot。

旧客户 Bot 若缺少上述平台隔离开关，必须先备份并由平台运维通过 AstrBot 原生 Bot 配置更新接口单独重载该客户 Bot；仅改磁盘文件不会改变已运行适配器的 `required_plugin`。新代码拒绝在旧配置上直接重试开通，不会静默开启不安全的客户 Bot。该设置仍属于同进程的**逻辑边界**，不能隔离拥有任意代码执行权的插件或维护人员。

## 兼容性与验收状态

- 生产 AstrBot v4.28.1 依赖本地扩展的 Telegram adapter 应用级 hook 和动态账号配置档所需的流水线生命周期支持；当前插件 ZIP **不**包含这些核心扩展。
- 对未修改的官方 v4.28.1 做过隔离导入与初始化探测：导入成功，绑定总控所需接口不存在，插件会明确报兼容性错误。这不是完整的原版启动、安装或生产收款验收。新 AstrBot 一键安装仍待支持的扩展接口或插件内实现。
- 已在当前生产底座验证一台测试客户 Bot 的创建/接入、群授权与一条标记为 AI 的回复；两租户实账号完整隔离、正式收款、全新原版安装及外部浏览器页面问题的最终复测**尚未完成**。
- 2026-09-28 已将既有测试客户 Bot `AIClient_8910402926` 迁移为专用消息入口：只订阅 `message`，必需插件标记与专用上报开启，关闭原生命令注册。对旧配置运行 `integrations/telethon-ai/migrate_customer_boundary.py` 可预检；`--apply` **仅限该测试 Bot**，通过本机管理 API 单独重载并将敏感配置备份在服务器私有目录。生产状态检查显示总控、客户 Bot、已启用的 collector 均在运行，另一个账号保持停用。未进行新的客户私聊实测或群发言测试。
- 自动化测试覆盖总控权限、租户额度、网关、客户登记、页面加载和生命周期。正式开放前仍需分别完成多租户隔离、备份恢复、重复事件、支付安全和实际发布验收。

文档与代码以本插件目录为准；上述状态记录基于 2026-09-28 的当前部署，未来更新请同步复测和修订本节。
