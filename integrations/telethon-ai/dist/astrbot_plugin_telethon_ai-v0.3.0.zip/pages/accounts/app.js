const bridge = window.AstrBotPluginPage;
const status = document.getElementById("status");
const body = document.getElementById("accounts");
const dialog = document.getElementById("resume-dialog");
let selected = null;

function cell(row, text, detail = "") {
  const td = document.createElement("td");
  td.textContent = text;
  if (detail) {
    const small = document.createElement("small");
    small.textContent = detail;
    td.append(small);
  }
  row.append(td);
  return td;
}

async function refresh() {
  const button = document.getElementById("refresh");
  button.disabled = true;
  try {
    const data = await bridge.apiGet("status");
    const selector = document.getElementById("account");
    const previous = selector.value;
    selector.replaceChildren();
    for (const account of data.accounts) {
      const option = document.createElement("option");
      option.value = account.account;
      option.textContent = account.account;
      selector.append(option);
    }
    if (data.accounts.some(a => a.account === previous)) selector.value = previous;
    document.getElementById("preview-submit").disabled = data.accounts.length === 0;
    body.replaceChildren();
    for (const account of data.accounts) {
      const row = document.createElement("tr");
      cell(row, account.account, account.user_id);
      cell(row, account.paused ? "已暂停" : account.state, account.enabled ? "平台已启用" : "平台未启用");
      cell(row, account.model, account.persona);
      cell(row, account.allowed_chats.length ? account.allowed_chats.join(", ") : "未授权群",
        account.disclosure_confirmed ? `${account.allowed_senders.length} 位授权成员` : "身份告知未确认");
      cell(row, String(account.daily_limit));
      const td = cell(row, "");
      const action = document.createElement("button");
      action.textContent = account.paused ? "解除暂停" : "紧急停用";
      action.addEventListener("click", async () => {
        if (account.paused) {
          selected = account.account;
          document.getElementById("resume-label").textContent = `账号：${selected}`;
          dialog.showModal();
          return;
        }
        action.disabled = true;
        try { await bridge.apiPost("pause", {account: account.account}); await refresh(); }
        catch (error) { status.textContent = error.message; }
        finally { action.disabled = false; }
      });
      td.append(action);
      body.append(row);
    }
    status.textContent = `已更新 · ${new Date().toLocaleTimeString()}`;
  } catch (error) { status.textContent = error.message; }
  finally { button.disabled = false; }
}
dialog.addEventListener("close", async () => {
  if (dialog.returnValue !== "confirm" || !selected) return;
  try { await bridge.apiPost("resume", {account: selected, confirm: true}); await refresh(); }
  catch (error) { status.textContent = error.message; }
  finally { selected = null; }
});
document.getElementById("refresh").addEventListener("click", refresh);
document.getElementById("preview-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = document.getElementById("preview-submit");
  const reply = document.getElementById("reply");
  button.disabled = true;
  reply.textContent = "生成中…";
  try {
    const result = await bridge.apiPost("preview", {
      account: document.getElementById("account").value,
      prompt: document.getElementById("prompt").value,
    });
    reply.textContent = result.reply;
  } catch (error) { reply.textContent = error.message; }
  finally { button.disabled = false; }
});
if (!bridge) status.textContent = "请从 AstrBot 插件详情打开此页面。";
else { await bridge.ready(); await refresh(); }
