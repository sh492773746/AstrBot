# AI Account Service Controller v0.3

One AstrBot plugin contains the Telegram control entry, customer Bot menus,
Managed Bot enrollment, trial entitlements, private account registry, Telethon
adapter, native AI profiles/personas and authenticated Plugin Page.
Formal payments remain disabled. This is a trial release, not a production-ready
paid service.

## First Installation

1. Install the ZIP through AstrBot's plugin installer.
2. Add your control Bot using AstrBot's native Telegram adapter.
3. Set this plugin's `control_platform_id`, numeric `admin_ids`, support contact
   and an existing model provider ID.
4. Bind a dedicated control profile: LLM off, built-in commands off,
   `plugin_set` containing only `astrbot_plugin_telethon_ai`.
5. Enable Bot Management Mode in BotFather. Subscribe the control adapter to
   `message`, `callback_query`, `managed_bot` and `pre_checkout_query`.
6. Set the adapter's `telegram_required_plugin` to this plugin where supported.
7. Register operator accounts from the server terminal using the AstrBot Python
   environment, working directory and data root:

```sh
python -m data.plugins.astrbot_plugin_telethon_ai.setup_account account_alias
```

API hash, phone, login code and 2FA password are interactive inputs, never sent
through customer Bots. Reload the plugin to create the account's native profile,
persona and disabled platform. No account automatically joins a group.

The runtime requires the Telegram adapter's application-hook methods. The reviewed
local AstrBot 4.28.1 provides them; a version number alone does not guarantee
compatibility with every upstream/fork build. Core is not automatically patched.

## Trial Workflow

In the control Bot's private chat, the configured super-admin can use:

- `/tgai`: management help and usage.
- `/tgaigrant OWNER_ID DAYS`: one 1-7 day trial, 30 total model-request admissions
  and one group by default.
- User `/create`: confirm Bot creation through Telegram's Managed Bot UI.
- `/tgaiassign TENANT_ID ACCOUNT`: exclusively allocate an account.
- `/tgaigroup TENANT_ID -100GROUP`: record an operator-reviewed authorized group.
- `/tgaienable TENANT_ID`, `/tgaidisable TENANT_ID`: enable/pause entitlement.
- `/tgairetry BOT_ID`: retry failed native enrollment without another Bot.
- `/tgairequests`: list customer group/resume/renewal requests.
- `/tgaiapprove REQUEST_ID`, `/tgaireject REQUEST_ID`: review a group/resume
  request after checking authorization. Paid renewal approval remains disabled.
- `/tgaistop`: emergency pause of every AI account.

Creation events produce a dedicated no-LLM customer profile and native Telegram
platform, not a Docker container. Tokens are encrypted in the plugin enrollment
database; AstrBot's native platform config also requires the Token, so protect the
whole AstrBot data directory.

Mutations except emergency pause require a private actor/chat-bound, single-use
confirmation valid for five minutes. Confirmations expire on reload.
Entitlement changes never start accounts or join groups.

Customer menus provide status, usage, pause, resume/renewal requests and support.
`/bind -100GROUP` submits a request, not a direct authorization.
Operations check actual platform, Bot and Telegram owner IDs.

## AI and Isolation

Models/personas use native AstrBot profiles. Seed personas are created once.
The account profiles exclude admins, built-in commands, other plugins and knowledge
bases in this release. LLM tools are removed. Customers cannot edit platform models,
prompts or tools.

Every request requires an active lease, authorized group and sender, AI disclosure,
remaining trial quota, cooldown and daily account budget. Only new text messages
mentioning/replying to the account enter the pipeline. Bots, other platform accounts,
private messages, forwarded messages and media are ignored. Replies start `[AI]`.

Leases and group ownership are exclusive. Context keys contain tenant, account
platform, group and sender. This is logical isolation in a trusted process, not
a sandbox against arbitrary Python plugins.

Quota is reserved atomically before AI processing, with one in-flight request per
tenant. Expiry/pause are checked before model generation and send. Requests reaching
the pipeline remain charged on failure or uncertain delivery, with no automatic
retry/refund. Send errors pause the account. Counts are not precise token/cost caps.

## Private Data

Data lives under `data/plugin_data/astrbot_plugin_telethon_ai/`.
`private/accounts.json` contains session references and credentials, never shipped
in the installation ZIP. The operator login helper creates sessions in `private/`.
Sessions have exclusive locks. Legacy imports also retain the collector guard.
Back up the SQLite DBs, encryption key, registry, sessions and native config securely.

## Migration and Remaining Work

Default `controller_mode=standalone` owns public commands and managed creation.
`companion` exists only for migration. Standalone mode refuses to coexist with an
active legacy controller on the same Bot.

Production migration on 2026-09-28 disabled the old controller plugin but retained
its code and DB. Only VIP_DHBot moved to this plugin; existing independent tenants
remain unchanged. Never automatically merge legacy orders/payment data.

Pending: real Managed Bot end-to-end creation acceptance, approved persona
selection, exact token/cost ceilings, paid renewals/refunds
and broader failure recovery. Account login currently uses a server-terminal
wizard, not a Telegram login-code workflow.
