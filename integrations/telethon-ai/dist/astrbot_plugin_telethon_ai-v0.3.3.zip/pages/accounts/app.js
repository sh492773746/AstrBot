(() => {
window.__aiServiceAppLoaded = true;
let bridge;
const status = document.getElementById("status");
const body = document.getElementById("accounts");
const dialog = document.getElementById("resume-dialog");
let selected = null;
const states = {running: "运行中", stopped: "已停止", pending: "连接中", error: "连接异常"};
const results = {sent: "已发送", reserved: "已预留 / 待核验", released: "已退回", uncertain: "发送结果不确定"};
const date = value => new Date(value * 1000).toLocaleString();
async function wait(promise, ms, message) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(message)), ms); }),
    ]);
  } finally { clearTimeout(timer); }
}
async function connect() {
  bridge = window.AstrBotPluginPage;
  if (!bridge) throw new Error("未检测到 AstrBot 插件桥接，请重新打开插件页面。");
  await wait(bridge.ready(), 8000, "插件桥接未建立，请检查父页面登录状态后重试；账号运行状态未知。");
}
const tabs = [...document.querySelectorAll('[role="tab"]')];
function activate(tab) {
  for (const item of tabs) {
    const active = item === tab;
    item.setAttribute("aria-selected", String(active));
    item.tabIndex = active ? 0 : -1;
    document.getElementById(`panel-${item.dataset.panel}`).hidden = !active;
  }
}
tabs.forEach((tab, index) => {
  tab.addEventListener("click", () => activate(tab));
  tab.addEventListener("keydown", event => {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    const next = event.key === "Home" ? 0 : event.key === "End" ? tabs.length - 1 :
      (index + (event.key === "ArrowRight" ? 1 : -1) + tabs.length) % tabs.length;
    activate(tabs[next]); tabs[next].focus();
  });
});
activate(tabs[0]);
function empty(target, columns, text) {
  if (target.children.length) return;
  const row = document.createElement("tr");
  cell(row, text).colSpan = columns;
  target.append(row);
}

function cell(row, text, detail = "") {
  const td = document.createElement("td");
  td.textContent = text;
  if (detail) {
    const small = document.createElement("small");
    small.textContent = detail;
    td.append(small);
  }
  row.append(td);
  return td;
}

async function refresh() {
  const button = document.getElementById("refresh");
  button.disabled = true;
  try {
    status.textContent = "正在读取运行状态…";
    await connect();
    const data = await wait(bridge.apiGet("status"), 12000, "状态接口无响应，请检查服务及页面授权后重试。");
    const overview = document.getElementById("overview");
    overview.replaceChildren();
    for (const [label, value] of [
      ["总控", data.control_attached ? "已连接" : "未连接"],
      ["账号连接", `${data.accounts.filter(a => a.state === "running").length} / ${data.accounts.length}`],
      ["租户", String(data.tenant_count)],
      ["客户入口", String(data.customer_entries)],
    ]) {
      const item = document.createElement("div");
      const title = document.createElement("span");
      title.textContent = label;
      const strong = document.createElement("strong");
      strong.textContent = value;
      item.append(title, strong); overview.append(item);
    }
    const selector = document.getElementById("account");
    const previous = selector.value;
    selector.replaceChildren();
    for (const account of data.accounts) {
      const option = document.createElement("option");
      option.value = account.account;
      option.textContent = account.account;
      selector.append(option);
    }
    if (data.accounts.some(a => a.account === previous)) selector.value = previous;
    document.getElementById("preview-submit").disabled = data.accounts.length === 0;
    body.replaceChildren();
    for (const account of data.accounts) {
      const row = document.createElement("tr");
      cell(row, account.account, `${account.user_id} · ${account.tenant || "未分配"}`);
      cell(row, account.paused ? "已紧急暂停" : (states[account.state] || account.state), account.enabled ? "连接配置已启用" : "连接配置未启用");
      cell(row, account.model, account.persona);
      cell(row, account.allowed_chats.length ? account.allowed_chats.join(", ") : "未授权群",
        account.disclosure_confirmed ? `${account.allowed_senders.length} 位授权成员` : "身份告知未确认");
      cell(row, `${account.daily_used} / ${account.daily_limit}`, `剩余 ${Math.max(0, account.daily_limit - account.daily_used)}`);
      const td = cell(row, "");
      const action = document.createElement("button");
      action.textContent = account.paused ? "解除暂停" : "紧急停用";
      action.addEventListener("click", async () => {
        if (account.paused) {
          selected = account.account;
          document.getElementById("resume-label").textContent = `账号：${selected}`;
          dialog.showModal();
          return;
        }
        action.disabled = true;
        try { await wait(bridge.apiPost("pause", {account: account.account}), 15000, "停用结果未确认，请刷新核验，不要重复操作。"); await refresh(); }
        catch (error) { status.textContent = error.message; }
        finally { action.disabled = false; }
      });
      td.append(action);
      body.append(row);
    }
    empty(body, 6, "暂无账号");
    const tenants = document.getElementById("tenants");
    tenants.replaceChildren();
    document.getElementById("tenant-count").textContent = `显示 ${data.tenants.length} / ${data.tenant_count} 个租户（最多 100 个）`;
    for (const tenant of data.tenants) {
      const row = document.createElement("tr");
      cell(row, tenant.id, `Bot ${tenant.bot}`);
      cell(row, tenant.owner);
      cell(row, tenant.expired ? "已到期" : tenant.enabled ? "已启用" : "已暂停");
      cell(row, `${tenant.remaining} / ${tenant.budget}`, `已用 ${tenant.used}`);
      cell(row, date(tenant.expires));
      cell(row, tenant.accounts.join(", ") || "未分配", tenant.groups.join(", ") || "未授权群");
      tenants.append(row);
    }
    empty(tenants, 6, "暂无租户");
    const checks = document.getElementById("checks");
    checks.replaceChildren();
    for (const [key, label] of Object.entries({
      telegram_hooks: "Telegram 接入钩子", hot_profile_pipeline: "本机热配置流水线接口",
      controller_bound: "总控处理器绑定",
    })) {
      const term = document.createElement("dt");
      const value = document.createElement("dd");
      term.textContent = label;
      value.textContent = data.checks[key] ? "已检测到" : "未检测到 · 需核验";
      value.className = data.checks[key] ? "ok" : "warning";
      checks.append(term, value);
    }
    const recent = document.getElementById("recent");
    recent.replaceChildren();
    for (const request of data.recent) {
      const row = document.createElement("tr");
      cell(row, date(request.created)); cell(row, request.account);
      cell(row, request.tenant); cell(row, results[request.state] || request.state);
      recent.append(row);
    }
    empty(recent, 4, "暂无请求");
    for (const table of document.querySelectorAll("table")) {
      const labels = [...table.querySelectorAll("th")].map(th => th.textContent);
      for (const row of table.querySelectorAll("tbody tr")) {
        [...row.children].forEach((td, index) => {
          td.dataset.label = row.children.length > 1 ? labels[index] : "";
        });
      }
    }
    status.textContent = `已更新 · ${new Date().toLocaleTimeString()}`;
  } catch (error) {
    status.textContent = `刷新失败，当前数据可能已过期：${error.message}`;
  }
  finally { button.disabled = false; }
}
dialog.addEventListener("close", async () => {
  if (dialog.returnValue !== "confirm" || !selected) return;
  try { await wait(bridge.apiPost("resume", {account: selected, confirm: true}), 15000, "解除暂停结果未确认，请刷新核验。"); await refresh(); }
  catch (error) { status.textContent = error.message; }
  finally { selected = null; }
});
document.getElementById("refresh").addEventListener("click", refresh);
document.getElementById("preview-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = document.getElementById("preview-submit");
  const reply = document.getElementById("reply");
  button.disabled = true;
  reply.textContent = "生成中…";
  try {
    await connect();
    const result = await wait(bridge.apiPost("preview", {
      account: document.getElementById("account").value,
      prompt: document.getElementById("prompt").value,
    }), 55000, "预览结果超时；请求可能已执行，请勿连续重试。");
    reply.textContent = result.reply;
  } catch (error) { reply.textContent = error.message; }
  finally { button.disabled = false; }
});
refresh();
})();
