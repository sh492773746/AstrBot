"""AstrBot-native account management; no independent HTTP server."""

import asyncio
import copy
import time
from datetime import datetime, timezone
from pathlib import Path

from astrbot.api import AstrBotConfig
from astrbot.api.event import filter
from astrbot.api.star import Context, Star
from astrbot.api.web import error_response, json_response, request
from astrbot.core.config.default import DEFAULT_CONFIG
from astrbot.core.workspace import API_KEY_USERNAME_PREFIX

from . import adapter, registry
from .control import Control
from .customer import Customer
from .enrollment import Enrollment
from .policy import Gate
from .tenants import Tenants

NAME = adapter.NAME


class TelethonAI(Star):
    def __init__(self, context: Context, config: AstrBotConfig):
        super().__init__(context)
        self.config = config
        self.gate = Gate(adapter.state_path())
        self.tenants = Tenants(adapter.state_path().with_name("tenants.db"))
        self.control = Control(self)
        self.enrollment = Enrollment(self)
        self.customers = {}
        self.preview_lock = asyncio.Lock()
        self.last_preview = 0
        self.closed = False
        adapter.CONTEXT = context

    async def initialize(self):
        adapter.ACCOUNTS.clear()
        adapter.ACCOUNTS.update(
            {key: int(spec["user_id"]) for key, spec in registry.load().items()}
        )
        if self.config.get("controller_mode", "standalone") not in {
            "standalone",
            "companion",
        }:
            raise ValueError("Unknown controller mode")
        if self.config.get("provision_profiles", True):
            await self.provision()
        self.control.bind()
        self.bind_customers()
        await self.control.publish_menu()
        for endpoint, handler, methods in (
            ("status", self.page_status, ["GET"]),
            ("pause", self.page_pause, ["POST"]),
            ("resume", self.page_resume, ["POST"]),
            ("preview", self.page_preview, ["POST"]),
        ):
            self.context.register_web_api(
                f"/{NAME}/{endpoint}", handler, methods, endpoint
            )

    @filter.on_platform_loaded()
    async def bind_control(self):
        if not self.closed:
            self.control.bind()
            self.bind_customers()

    def bind_customers(self):
        for row in self.tenants.db.execute("SELECT platform FROM tenants"):
            platform_id = row[0]
            if platform_id not in self.customers:
                self.customers[platform_id] = Customer(self, platform_id)
            self.customers[platform_id].bind()

    async def provision(self):
        manager = self.context.astrbot_config_mgr
        platform_id = self.config.get("control_platform_id", "VIP_DHBot")
        vip = self.context.get_config(f"{platform_id}:FriendMessage:0")
        model_id = self.config.get("model_provider_id") or (
            vip.get("agent_runner", {})
            .get("config", {})
            .get("model", {})
            .get("provider_id")
        )
        if not model_id and adapter.ACCOUNTS:
            raise ValueError(
                "VIP profile has no model selection; refusing implicit fallback"
            )
        for account in adapter.ACCOUNTS:
            platform_id = f"TelethonAI_{account}"
            persona_id = f"telethon-ai-{account}"
            if self.context.persona_manager.get_persona_v3_by_id(persona_id) is None:
                await self.context.persona_manager.create_persona(
                    persona_id,
                    (Path(__file__).parent / "SOUL.md").read_text(encoding="utf-8"),
                    tools=[],
                    skills=[],
                )
            name = f"Telethon AI - {account}"
            matches = [c for c in manager.get_conf_list() if c["name"] == name]
            if len(matches) > 1:
                raise ValueError("Duplicate Telethon profile; operator review required")
            if matches:
                conf_id = matches[0]["id"]
            else:
                conf = copy.deepcopy(DEFAULT_CONFIG)
                conf["admins_id"] = []
                conf["disable_builtin_commands"] = True
                conf["plugin_set"] = [NAME]
                conf["wake_prefix"] = []
                conf["provider_settings"]["enable"] = True
                conf["provider_settings"]["proactive_capability"]["add_cron_tools"] = (
                    False
                )
                conf["agent_runner"]["config"]["model"]["provider_id"] = model_id
                conf["agent_runner"]["config"]["model"]["fallback_provider_ids"] = []
                conf["agent_runner"]["config"]["persona"]["persona_id"] = persona_id
                conf["provider_settings"]["persona_pool"] = [persona_id]
                conf["kb_names"] = []
                conf["kb_agentic_mode"] = False
                conf_id = await manager.create_conf(conf, name=name)
            route = f"{platform_id}::"
            previous = manager.ucr.umop_to_conf_id.get(route)
            if previous and previous != conf_id:
                raise ValueError("Telethon profile routing conflict")
            await manager.ucr.update_route(route, conf_id)
            root = manager.default_conf
            platforms = root.setdefault("platform", [])
            existing = next((p for p in platforms if p.get("id") == platform_id), None)
            if existing is None:
                platform = copy.deepcopy(adapter.DEFAULT)
                platform.update(id=platform_id, account=account)
                platforms.append(platform)
                root.save_config()
            elif (
                existing.get("type") != "telethon_ai"
                or existing.get("account") != account
            ):
                raise ValueError("Telethon platform identity collision")

    def dashboard_admin(self):
        return (
            not self.closed
            and request.username
            and not request.username.startswith(API_KEY_USERNAME_PREFIX)
        )

    def accounts(self):
        rows = []
        for account, uid in adapter.ACCOUNTS.items():
            platform_id = f"TelethonAI_{account}"
            platform = self.context.get_platform_inst(platform_id)
            config = next(
                (
                    p
                    for p in self.context.get_config().get("platform", [])
                    if p.get("id") == platform_id
                ),
                {},
            )
            profile = self.context.get_config(f"{platform_id}:GroupMessage:0")
            runner = profile.get("agent_runner", {}).get("config", {})
            rows.append(
                {
                    "account": account,
                    "user_id": str(uid),
                    "platform_id": platform_id,
                    "state": platform.status.value if platform else "stopped",
                    "enabled": config.get("enable", False),
                    "paused": self.gate.paused(account),
                    "allowed_chats": config.get("allowed_chats", []),
                    "allowed_senders": config.get("allowed_senders", []),
                    "disclosure_confirmed": config.get("disclosure_confirmed", False),
                    "daily_limit": config.get("daily_limit", 30),
                    "model": runner.get("model", {}).get("provider_id", ""),
                    "persona": runner.get("persona", {}).get("persona_id", ""),
                }
            )
        return rows

    async def page_status(self):
        if not self.dashboard_admin():
            return error_response("Administrator required", status_code=403)
        return json_response(self.operational_status())

    def operational_status(self):
        from astrbot.core.event_bus import EventBus

        accounts = self.accounts()
        day = datetime.now(timezone.utc).date().isoformat()
        tenants = []
        for row in self.tenants.db.execute("SELECT id FROM tenants ORDER BY expires LIMIT 100"):
            info = self.tenants.summary(row["id"])
            info["remaining"] = max(0, info["budget"] - info["used"])
            info["expired"] = info["expires"] <= time.time()
            tenants.append(info)
        for account in accounts:
            account["daily_used"] = self.gate.db.execute(
                "SELECT COUNT(*) FROM attempts WHERE account=? AND day=?",
                (account["account"], day),
            ).fetchone()[0]
            lease = self.tenants.db.execute(
                "SELECT tenant FROM leases WHERE account=?", (account["account"],)
            ).fetchone()
            account["tenant"] = lease[0] if lease else None
        platform = self.control.platform
        return (
            {
                "accounts": accounts,
                "tenants": tenants,
                "recent": [dict(row) for row in self.tenants.db.execute(
                    "SELECT account,tenant,created,state FROM reservations ORDER BY created DESC LIMIT 20"
                )],
                "checks": {
                    "telegram_hooks": bool(platform and callable(getattr(platform, "register_application_hook", None))),
                    "hot_profile_pipeline": callable(getattr(EventBus, "ensure_scheduler", None)),
                    "controller_bound": self.control.application is not None,
                },
                "generated_at": time.time(),
                "control_attached": self.control.application is not None,
                "tenant_count": self.tenants.db.execute(
                    "SELECT COUNT(*) FROM tenants"
                ).fetchone()[0],
                "customer_entries": len(self.customers),
            }
        )

    async def pause(self, account):
        self.gate.pause(account)
        platform = self.context.get_platform_inst(f"TelethonAI_{account}")
        if platform:
            await platform.terminate()

    async def page_pause(self):
        if not self.dashboard_admin():
            return error_response("Administrator required", status_code=403)
        body = await request.json(default={})
        if not isinstance(body, dict) or body.get("account") not in adapter.ACCOUNTS:
            return error_response("Unknown account")
        await self.pause(body["account"])
        return json_response({"paused": True})

    async def page_resume(self):
        if not self.dashboard_admin():
            return error_response("Administrator required", status_code=403)
        body = await request.json(default={})
        if (
            not isinstance(body, dict)
            or body.get("account") not in adapter.ACCOUNTS
            or body.get("confirm") is not True
        ):
            return error_response("Explicit account confirmation required")
        self.gate.pause(body["account"], False)
        # Connection still requires explicit platform enable/restart in AstrBot.
        return json_response({"paused": False, "connected": False})

    async def page_preview(self):
        if not self.dashboard_admin():
            return error_response("Administrator required", status_code=403)
        body = await request.json(default={})
        if not isinstance(body, dict) or body.get("account") not in adapter.ACCOUNTS:
            return error_response("Unknown account")
        prompt = body.get("prompt")
        if not isinstance(prompt, str) or not 1 <= len(prompt.strip()) <= 500:
            return error_response("Prompt must be 1-500 characters")
        if self.preview_lock.locked() or time.monotonic() - self.last_preview < 10:
            return error_response("Preview rate limit", status_code=429)
        async with self.preview_lock:
            self.last_preview = time.monotonic()
            umo = f"TelethonAI_{body['account']}:GroupMessage:preview"
            conf = self.context.get_config(umo)
            runner = conf.get("agent_runner", {}).get("config", {})
            persona_id = runner.get("persona", {}).get("persona_id")
            persona = self.context.persona_manager.get_persona_v3_by_id(persona_id)
            if not persona or not conf.get("provider_settings", {}).get("enable"):
                return error_response("Profile/model/persona unavailable")
            try:
                response = await asyncio.wait_for(
                    self.context.llm_generate(
                        chat_provider_id=runner["model"]["provider_id"],
                        prompt=prompt,
                        system_prompt=persona["prompt"],
                        contexts=[],
                        tools=None,
                        max_tokens=200,
                    ),
                    timeout=45,
                )
            except Exception:
                return error_response("Model preview failed", status_code=502)
            return json_response(
                {"reply": response.completion_text, "sent_to_telegram": False}
            )

    @filter.on_llm_request()
    async def guard(self, event, req):
        if event.get_platform_name() == "telethon_ai":
            req.func_tool = None
            if not isinstance(
                event, adapter.TelethonEvent
            ) or not event.adapter.tenants.can_send(event.reservation):
                event.stop_event()

    def is_admin(self, event):
        return (
            not self.closed
            and event.is_private_chat()
            and event.get_platform_id() == self.config.get("control_platform_id")
            and str(event.get_sender_id()) in self.config.get("admin_ids", [])
        )

    @filter.command("tgai")
    async def status_command(self, event):
        if not self.is_admin(event):
            event.stop_event()
            return
        yield event.plain_result(
            "\n".join(
                f"{r['account']}: {r['state']}; paused={r['paused']}; "
                f"model={r['model']}; persona={r['persona']}"
                for r in self.accounts()
            )
        )
        event.stop_event()

    @filter.command("tgaistop")
    async def stop_command(self, event):
        if not self.is_admin(event):
            event.stop_event()
            return
        for account in adapter.ACCOUNTS:
            await self.pause(account)
        yield event.plain_result("两个 Telethon AI 账号已紧急暂停。")
        event.stop_event()

    async def terminate(self):
        self.closed = True
        if (
            self.control.platform
            and self.control.standalone
            and getattr(self.control.platform, "required_plugin", None) == NAME
        ):
            await self.control.platform.suspend_required_plugin(NAME)
        active = set(self.control.active)
        active.discard(asyncio.current_task())
        if active:
            await asyncio.gather(*active, return_exceptions=True)
        self.control.detach()
        for customer in self.customers.values():
            customer.detach()
        for account in adapter.ACCOUNTS:
            platform = self.context.get_platform_inst(f"TelethonAI_{account}")
            if platform:
                await platform.terminate()
        adapter.CONTEXT = None
        self.gate.close()
        self.tenants.close()
